﻿namespace Monopoly
{
    partial class Form1
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Feld10ER = new System.Windows.Forms.PictureBox();
            this.Feld9 = new System.Windows.Forms.PictureBox();
            this.Feld8 = new System.Windows.Forms.PictureBox();
            this.Feld6Gef = new System.Windows.Forms.PictureBox();
            this.Feld7 = new System.Windows.Forms.PictureBox();
            this.Feld11 = new System.Windows.Forms.PictureBox();
            this.Feld12 = new System.Windows.Forms.PictureBox();
            this.Feld13 = new System.Windows.Forms.PictureBox();
            this.Feld14 = new System.Windows.Forms.PictureBox();
            this.Feld15 = new System.Windows.Forms.PictureBox();
            this.Feld16 = new System.Windows.Forms.PictureBox();
            this.Feld17 = new System.Windows.Forms.PictureBox();
            this.Feld18 = new System.Windows.Forms.PictureBox();
            this.Feld19 = new System.Windows.Forms.PictureBox();
            this.Feld20 = new System.Windows.Forms.PictureBox();
            this.Feld2ER = new System.Windows.Forms.PictureBox();
            this.Feld3 = new System.Windows.Forms.PictureBox();
            this.Feld4 = new System.Windows.Forms.PictureBox();
            this.Feld5 = new System.Windows.Forms.PictureBox();
            this.Feld1los = new System.Windows.Forms.PictureBox();
            this.Player1 = new System.Windows.Forms.PictureBox();
            this.Würfel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld10ER)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld6Gef)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld2ER)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld1los)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(164, 92);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(473, 456);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Feld10ER
            // 
            this.Feld10ER.BackColor = System.Drawing.Color.White;
            this.Feld10ER.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Feld10ER.BackgroundImage")));
            this.Feld10ER.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Feld10ER.Location = new System.Drawing.Point(532, 14);
            this.Feld10ER.Name = "Feld10ER";
            this.Feld10ER.Size = new System.Drawing.Size(81, 83);
            this.Feld10ER.TabIndex = 1;
            this.Feld10ER.TabStop = false;
            // 
            // Feld9
            // 
            this.Feld9.BackColor = System.Drawing.Color.AntiqueWhite;
            this.Feld9.Location = new System.Drawing.Point(445, 14);
            this.Feld9.Name = "Feld9";
            this.Feld9.Size = new System.Drawing.Size(81, 83);
            this.Feld9.TabIndex = 2;
            this.Feld9.TabStop = false;
            // 
            // Feld8
            // 
            this.Feld8.BackColor = System.Drawing.Color.AntiqueWhite;
            this.Feld8.Location = new System.Drawing.Point(358, 14);
            this.Feld8.Name = "Feld8";
            this.Feld8.Size = new System.Drawing.Size(81, 83);
            this.Feld8.TabIndex = 3;
            this.Feld8.TabStop = false;
            // 
            // Feld6Gef
            // 
            this.Feld6Gef.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Feld6Gef.BackgroundImage")));
            this.Feld6Gef.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Feld6Gef.Location = new System.Drawing.Point(184, 14);
            this.Feld6Gef.Name = "Feld6Gef";
            this.Feld6Gef.Size = new System.Drawing.Size(81, 83);
            this.Feld6Gef.TabIndex = 4;
            this.Feld6Gef.TabStop = false;
            // 
            // Feld7
            // 
            this.Feld7.BackColor = System.Drawing.Color.Wheat;
            this.Feld7.Location = new System.Drawing.Point(271, 14);
            this.Feld7.Name = "Feld7";
            this.Feld7.Size = new System.Drawing.Size(81, 83);
            this.Feld7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.Feld7.TabIndex = 5;
            this.Feld7.TabStop = false;
            this.Feld7.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // Feld11
            // 
            this.Feld11.BackColor = System.Drawing.Color.Blue;
            this.Feld11.Location = new System.Drawing.Point(622, 103);
            this.Feld11.Name = "Feld11";
            this.Feld11.Size = new System.Drawing.Size(81, 83);
            this.Feld11.TabIndex = 6;
            this.Feld11.TabStop = false;
            this.Feld11.Click += new System.EventHandler(this.pictureBox7_Click);
            // 
            // Feld12
            // 
            this.Feld12.BackColor = System.Drawing.Color.Blue;
            this.Feld12.Location = new System.Drawing.Point(622, 192);
            this.Feld12.Name = "Feld12";
            this.Feld12.Size = new System.Drawing.Size(81, 83);
            this.Feld12.TabIndex = 7;
            this.Feld12.TabStop = false;
            this.Feld12.Click += new System.EventHandler(this.pictureBox8_Click);
            // 
            // Feld13
            // 
            this.Feld13.BackColor = System.Drawing.Color.BlueViolet;
            this.Feld13.Location = new System.Drawing.Point(622, 281);
            this.Feld13.Name = "Feld13";
            this.Feld13.Size = new System.Drawing.Size(81, 83);
            this.Feld13.TabIndex = 8;
            this.Feld13.TabStop = false;
            // 
            // Feld14
            // 
            this.Feld14.BackColor = System.Drawing.Color.BlueViolet;
            this.Feld14.Location = new System.Drawing.Point(622, 370);
            this.Feld14.Name = "Feld14";
            this.Feld14.Size = new System.Drawing.Size(81, 83);
            this.Feld14.TabIndex = 9;
            this.Feld14.TabStop = false;
            // 
            // Feld15
            // 
            this.Feld15.BackColor = System.Drawing.Color.BlueViolet;
            this.Feld15.Location = new System.Drawing.Point(622, 459);
            this.Feld15.Name = "Feld15";
            this.Feld15.Size = new System.Drawing.Size(81, 83);
            this.Feld15.TabIndex = 10;
            this.Feld15.TabStop = false;
            // 
            // Feld16
            // 
            this.Feld16.BackColor = System.Drawing.Color.Aqua;
            this.Feld16.Location = new System.Drawing.Point(532, 538);
            this.Feld16.Name = "Feld16";
            this.Feld16.Size = new System.Drawing.Size(81, 83);
            this.Feld16.TabIndex = 11;
            this.Feld16.TabStop = false;
            // 
            // Feld17
            // 
            this.Feld17.BackColor = System.Drawing.Color.Aqua;
            this.Feld17.Location = new System.Drawing.Point(445, 538);
            this.Feld17.Name = "Feld17";
            this.Feld17.Size = new System.Drawing.Size(81, 83);
            this.Feld17.TabIndex = 12;
            this.Feld17.TabStop = false;
            // 
            // Feld18
            // 
            this.Feld18.BackColor = System.Drawing.Color.Aqua;
            this.Feld18.Location = new System.Drawing.Point(358, 538);
            this.Feld18.Name = "Feld18";
            this.Feld18.Size = new System.Drawing.Size(81, 83);
            this.Feld18.TabIndex = 13;
            this.Feld18.TabStop = false;
            // 
            // Feld19
            // 
            this.Feld19.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.Feld19.Location = new System.Drawing.Point(271, 538);
            this.Feld19.Name = "Feld19";
            this.Feld19.Size = new System.Drawing.Size(81, 83);
            this.Feld19.TabIndex = 14;
            this.Feld19.TabStop = false;
            // 
            // Feld20
            // 
            this.Feld20.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.Feld20.Location = new System.Drawing.Point(184, 538);
            this.Feld20.Name = "Feld20";
            this.Feld20.Size = new System.Drawing.Size(81, 83);
            this.Feld20.TabIndex = 15;
            this.Feld20.TabStop = false;
            this.Feld20.Click += new System.EventHandler(this.Feld20_Click);
            // 
            // Feld2ER
            // 
            this.Feld2ER.BackColor = System.Drawing.Color.White;
            this.Feld2ER.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Feld2ER.BackgroundImage")));
            this.Feld2ER.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Feld2ER.Location = new System.Drawing.Point(97, 370);
            this.Feld2ER.Name = "Feld2ER";
            this.Feld2ER.Size = new System.Drawing.Size(81, 83);
            this.Feld2ER.TabIndex = 16;
            this.Feld2ER.TabStop = false;
            // 
            // Feld3
            // 
            this.Feld3.BackColor = System.Drawing.Color.OliveDrab;
            this.Feld3.Location = new System.Drawing.Point(97, 281);
            this.Feld3.Name = "Feld3";
            this.Feld3.Size = new System.Drawing.Size(81, 83);
            this.Feld3.TabIndex = 18;
            this.Feld3.TabStop = false;
            // 
            // Feld4
            // 
            this.Feld4.BackColor = System.Drawing.Color.OliveDrab;
            this.Feld4.Location = new System.Drawing.Point(97, 192);
            this.Feld4.Name = "Feld4";
            this.Feld4.Size = new System.Drawing.Size(81, 83);
            this.Feld4.TabIndex = 19;
            this.Feld4.TabStop = false;
            // 
            // Feld5
            // 
            this.Feld5.BackColor = System.Drawing.Color.OliveDrab;
            this.Feld5.Location = new System.Drawing.Point(97, 103);
            this.Feld5.Name = "Feld5";
            this.Feld5.Size = new System.Drawing.Size(81, 83);
            this.Feld5.TabIndex = 20;
            this.Feld5.TabStop = false;
            // 
            // Feld1los
            // 
            this.Feld1los.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Feld1los.BackgroundImage")));
            this.Feld1los.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Feld1los.Location = new System.Drawing.Point(97, 459);
            this.Feld1los.Name = "Feld1los";
            this.Feld1los.Size = new System.Drawing.Size(81, 83);
            this.Feld1los.TabIndex = 21;
            this.Feld1los.TabStop = false;
            // 
            // Player1
            // 
            this.Player1.BackColor = System.Drawing.Color.Black;
            this.Player1.Location = new System.Drawing.Point(126, 490);
            this.Player1.Name = "Player1";
            this.Player1.Size = new System.Drawing.Size(21, 21);
            this.Player1.TabIndex = 22;
            this.Player1.TabStop = false;
            this.Player1.Click += new System.EventHandler(this.Player1_Click);
            // 
            // Würfel
            // 
            this.Würfel.Location = new System.Drawing.Point(330, 370);
            this.Würfel.Name = "Würfel";
            this.Würfel.Size = new System.Drawing.Size(126, 42);
            this.Würfel.TabIndex = 23;
            this.Würfel.Text = "Würfel";
            this.Würfel.UseVisualStyleBackColor = true;
            this.Würfel.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Agency FB", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(365, 281);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 39);
            this.label1.TabIndex = 24;
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(759, 633);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Würfel);
            this.Controls.Add(this.Player1);
            this.Controls.Add(this.Feld1los);
            this.Controls.Add(this.Feld5);
            this.Controls.Add(this.Feld4);
            this.Controls.Add(this.Feld3);
            this.Controls.Add(this.Feld2ER);
            this.Controls.Add(this.Feld20);
            this.Controls.Add(this.Feld19);
            this.Controls.Add(this.Feld18);
            this.Controls.Add(this.Feld17);
            this.Controls.Add(this.Feld16);
            this.Controls.Add(this.Feld15);
            this.Controls.Add(this.Feld14);
            this.Controls.Add(this.Feld13);
            this.Controls.Add(this.Feld12);
            this.Controls.Add(this.Feld11);
            this.Controls.Add(this.Feld7);
            this.Controls.Add(this.Feld6Gef);
            this.Controls.Add(this.Feld8);
            this.Controls.Add(this.Feld9);
            this.Controls.Add(this.Feld10ER);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld10ER)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld6Gef)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld2ER)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Feld1los)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Player1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox Feld10ER;
        private System.Windows.Forms.PictureBox Feld9;
        private System.Windows.Forms.PictureBox Feld8;
        private System.Windows.Forms.PictureBox Feld6Gef;
        private System.Windows.Forms.PictureBox Feld7;
        private System.Windows.Forms.PictureBox Feld11;
        private System.Windows.Forms.PictureBox Feld12;
        private System.Windows.Forms.PictureBox Feld13;
        private System.Windows.Forms.PictureBox Feld14;
        private System.Windows.Forms.PictureBox Feld15;
        private System.Windows.Forms.PictureBox Feld16;
        private System.Windows.Forms.PictureBox Feld17;
        private System.Windows.Forms.PictureBox Feld18;
        private System.Windows.Forms.PictureBox Feld19;
        private System.Windows.Forms.PictureBox Feld20;
        private System.Windows.Forms.PictureBox Feld2ER;
        private System.Windows.Forms.PictureBox Feld3;
        private System.Windows.Forms.PictureBox Feld4;
        private System.Windows.Forms.PictureBox Feld5;
        private System.Windows.Forms.PictureBox Feld1los;
        private System.Windows.Forms.PictureBox Player1;
        private System.Windows.Forms.Button Würfel;
        private System.Windows.Forms.Label label1;
    }
}

