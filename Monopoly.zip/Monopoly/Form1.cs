﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Monopoly
{
    public partial class Form1 : Form
    {
        public PictureBox[] pictureboxarray;
        public int playerlocation;
        
        public Form1()
        {
            InitializeComponent();

            pictureboxarray = new PictureBox[] {Feld1los, Feld2ER, Feld3, Feld4, Feld5, Feld6Gef, Feld7, Feld8, Feld9, Feld10ER, Feld11, Feld12, Feld13, Feld14, Feld15, Feld16, Feld17, Feld18, Feld19, Feld20};
            playerlocation = 0;


        }



        



        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void Player1_Click(object sender, EventArgs e)
        {
            
            
        }


        
        private void button1_Click(object sender, EventArgs e)
        {
            Random generator = new Random();
            int newNumber = generator.Next(2, 13);
            label1.Text = newNumber.ToString();



            

          
            

            playerlocation = playerlocation + newNumber;

            

            int playerx = pictureboxarray[playerlocation % 20].Location.X;
            int playery = pictureboxarray[playerlocation % 20].Location.Y;   


            int currentx = pictureboxarray[0].Location.X;


          
            Player1.Location = new Point(playerx, playery);








        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Feld20_Click(object sender, EventArgs e)
        {

        }
    }
}
