﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Monopoly
{
    public partial class Form1 : Form
    {
        public PictureBox[] pictureboxarray;
        public int playerlocation;
        public int money;
        int t = 0;
        int s = 0;
        int m = 0;
        
        public Form1()
        {
            InitializeComponent();
            money = 0;
            pictureboxarray = new PictureBox[] { Feld1los, Feld2ER, Feld3, Feld4, Feld5, Feld6Gef, Feld7, Feld8, Feld9, Feld10ER, Feld11, Feld12, Feld13, Feld14, Feld15, Feld16, Feld17, Feld18, Feld19, Feld20 };
            playerlocation = 0;
            
            time.Text = m.ToString() + " : " + s.ToString();
            timer1.Start();

        }







        private void pictureBox1_Click(object sender, EventArgs e)
        {
            
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {

        }

        private void Player1_Click(object sender, EventArgs e)
        {


        }



        private void button1_Click(object sender, EventArgs e)
        {
            Random generator = new Random();
            int newNumber = generator.Next(2, 13);
            label1.Text = newNumber.ToString();

            if (playerlocation == 0)
            {
                Random Events = new Random();
                int newEvent = generator.Next(1, 5);

                switch (newEvent)
                {

                    case 1:
                        money = money + 50;
                        label2.Text = money.ToString();
                        break;

                    case 2:
                        playerlocation = 12;
                        break;
                    case 3:
                        playerlocation = 4;
                        break;
                    case 4:
                        money = money - 50;
                        label2.Text = money.ToString();
                        break;

                    case 5:
                        money = money - 100;
                        label2.Text = money.ToString();
                        break;
                }


            }

            if (playerlocation == 8)
            {
                playerlocation = 4;
            }

            if (playerlocation == 1)
            {
                money = money + 200;
            }




            playerlocation = playerlocation + newNumber;



            int playerx = pictureboxarray[playerlocation % 20].Location.X;
            int playery = pictureboxarray[playerlocation % 20].Location.Y;





            int currentx = pictureboxarray[0].Location.X;



            Player1.Location = new Point(playerx, playery);


        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Feld20_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            money = money + 200;
            label2.Text = money.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            money = money - 200;
            label2.Text = money.ToString();
        }

        private void Aufgeben_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            t++;

            if (t == 10)
            {

                
                

                t = 0;
                s++;
                time.Text = m.ToString() + " : " + s.ToString();




                if (s == 60)
                {
                    m++;
                    s = 0;
                    time.Text = m.ToString() + " : " + s.ToString();

                }
            }
        }
    }
}
